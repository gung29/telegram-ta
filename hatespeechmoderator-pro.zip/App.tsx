import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { Stats } from './components/Stats';
import { Logs } from './components/Logs';
import { Verification } from './components/Verification';
import { AdminPanel } from './components/AdminPanel';
import { View } from './types';

function App() {
  const [currentView, setCurrentView] = useState<View>(View.DASHBOARD);

  const renderView = () => {
    switch (currentView) {
      case View.DASHBOARD:
        return <Dashboard />;
      case View.STATS:
        return <Stats />;
      case View.LOGS:
        return <Logs />;
      case View.VERIFY:
        return <Verification />;
      case View.ADMIN:
        return <AdminPanel />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <Layout currentView={currentView} onViewChange={setCurrentView}>
      {renderView()}
    </Layout>
  );
}

export default App;