import React from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { UserOffender } from '../types';

const data = [
  { name: '1', total: 5, warn: 2, block: 0 },
  { name: '2', total: 17, warn: 9, block: 5 },
  { name: '4', total: 19, warn: 10, block: 4 },
  { name: '6', total: 15, warn: 7, block: 2 },
  { name: '8', total: 29, warn: 18, block: 12 },
  { name: '10', total: 18, warn: 8, block: 5 },
  { name: '12', total: 28, warn: 14, block: 8 },
];

const pieData = [
  { name: 'Warned', value: 45, color: '#f59e0b' }, // Amber
  { name: 'Muted', value: 35, color: '#6366f1' },  // Indigo
  { name: 'Blocked', value: 20, color: '#ef4444' }, // Red
];

const topOffenders: UserOffender[] = [
    { id: '1', username: 'CryptoKing_99', userId: '12345', warnings: 15, mutes: 10, lastActivity: '5m', avatarId: 12 },
    { id: '2', username: 'PoliticalRage', userId: '67890', warnings: 12, mutes: 6, lastActivity: '2h', avatarId: 34 },
    { id: '3', username: 'SpamBot_X', userId: '54321', warnings: 8, mutes: 4, lastActivity: '1d', avatarId: 56 },
];

export const Stats: React.FC = () => {
  return (
    <div className="p-4 space-y-6 pb-24 animate-fade-in">
        
        {/* Date Filter */}
        <div className="flex bg-slate-800 p-1 rounded-xl">
            {['Today', '7 Days', '30 Days', 'All Time'].map((p, i) => (
                <button key={p} className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-all ${i === 1 ? 'bg-slate-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'}`}>
                    {p}
                </button>
            ))}
        </div>

        {/* Activity Chart */}
        <div className="glass-panel p-5 rounded-3xl border border-slate-700/50">
            <h3 className="text-white font-bold mb-1">Moderation Activity</h3>
            <div className="flex space-x-4 text-xs mb-4">
                <span className="flex items-center text-blue-400"><span className="w-2 h-2 rounded-full bg-blue-400 mr-1"></span> Total</span>
                <span className="flex items-center text-orange-400"><span className="w-2 h-2 rounded-full bg-orange-400 mr-1"></span> Warned</span>
                <span className="flex items-center text-red-400"><span className="w-2 h-2 rounded-full bg-red-400 mr-1"></span> Blocked</span>
            </div>
            <div className="h-48 w-full">
                <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={data}>
                        <defs>
                            <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                            </linearGradient>
                            <linearGradient id="colorWarn" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#f97316" stopOpacity={0.3}/>
                                <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                            </linearGradient>
                        </defs>
                        <XAxis dataKey="name" stroke="#475569" fontSize={10} tickLine={false} axisLine={false} />
                        <YAxis stroke="#475569" fontSize={10} tickLine={false} axisLine={false} />
                        <Tooltip 
                            contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                            itemStyle={{ color: '#e2e8f0' }}
                        />
                        <Area type="monotone" dataKey="total" stroke="#3b82f6" strokeWidth={2} fillOpacity={1} fill="url(#colorTotal)" />
                        <Area type="monotone" dataKey="warn" stroke="#f97316" strokeWidth={2} fillOpacity={1} fill="url(#colorWarn)" />
                        <Area type="monotone" dataKey="block" stroke="#ef4444" strokeWidth={2} fillOpacity={0} fill="transparent" />
                    </AreaChart>
                </ResponsiveContainer>
            </div>
        </div>

        {/* Composition Chart */}
        <div className="glass-panel p-5 rounded-3xl border border-slate-700/50 flex items-center justify-between">
            <div className="w-1/2">
                <h3 className="text-white font-bold mb-4">Action<br/>Composition</h3>
                <div className="space-y-2">
                    {pieData.map((entry) => (
                        <div key={entry.name} className="flex items-center justify-between text-xs">
                             <div className="flex items-center">
                                 <div className="w-2 h-2 rounded-full mr-2" style={{ backgroundColor: entry.color }}></div>
                                 <span className="text-slate-300">{entry.name}</span>
                             </div>
                             <span className="font-mono text-white">{entry.value}%</span>
                        </div>
                    ))}
                </div>
            </div>
            <div className="w-1/2 h-32 relative">
                <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                        <Pie
                            data={pieData}
                            cx="50%"
                            cy="50%"
                            innerRadius={30}
                            outerRadius={55}
                            paddingAngle={5}
                            dataKey="value"
                            stroke="none"
                        >
                            {pieData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                        </Pie>
                    </PieChart>
                </ResponsiveContainer>
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                   <span className="text-xs font-bold text-slate-500">Total</span> 
                </div>
            </div>
        </div>

        {/* Top Offenders List */}
        <div>
            <div className="flex justify-between items-center mb-3 px-1">
                <h3 className="text-white font-bold">Top Offenders</h3>
                <span className="text-xs text-slate-500">Last 7 Days</span>
            </div>
            <div className="space-y-3">
                {topOffenders.map((user, idx) => (
                    <div key={user.id} className="glass-panel p-3 rounded-2xl flex items-center space-x-3">
                        <img src={`https://picsum.photos/40/40?random=${user.avatarId}`} alt="avatar" className="w-10 h-10 rounded-full border border-slate-600" />
                        <div className="flex-1 min-w-0">
                            <h4 className="text-sm font-bold text-white truncate">{user.username}</h4>
                            <div className="text-[10px] text-slate-400 font-mono">ID: {user.userId}</div>
                        </div>
                        <div className="text-right">
                             <div className="text-sm font-bold text-neon-blue">{user.warnings + user.mutes} acts</div>
                             <div className="w-24 h-1.5 bg-slate-800 rounded-full mt-1 overflow-hidden">
                                 <div 
                                    className="h-full bg-gradient-to-r from-blue-500 to-purple-500" 
                                    style={{ width: `${(1 - idx * 0.2) * 100}%` }}
                                 ></div>
                             </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>

    </div>
  );
};