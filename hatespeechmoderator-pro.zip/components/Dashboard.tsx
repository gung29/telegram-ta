import React, { useState, useEffect } from 'react';
import { RefreshCw, Power, Shield, AlertTriangle, UserX, VolumeX } from 'lucide-react';

export const Dashboard: React.FC = () => {
  const [manualMode, setManualMode] = useState(false);
  const [lastUpdate, setLastUpdate] = useState("Just now");
  const [refreshing, setRefreshing] = useState(false);

  const handleRefresh = () => {
    setRefreshing(true);
    setTimeout(() => {
      setLastUpdate("Just now");
      setRefreshing(false);
    }, 1500);
  };

  const groups = [
    { id: 1, name: "Testing Ujaran Kebencian 2", cid: "-5065978190", active: true },
    { id: 2, name: "Crypto Talk Global", cid: "-1002938475", active: false },
    { id: 3, name: "Politic Debate (Supergroup)", cid: "-99882211", active: true },
  ];

  return (
    <div className="p-4 space-y-6 pb-24 animate-fade-in">
      {/* Header Status Card */}
      <div className="glass-panel p-5 rounded-3xl relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-4 opacity-10">
          <Shield size={120} />
        </div>
        <div className="relative z-10">
            <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                    <div className={`w-3 h-3 rounded-full ${manualMode ? 'bg-orange-500 animate-pulse' : 'bg-neon-green shadow-[0_0_10px_#0aff68]'}`}></div>
                    <h2 className="text-lg font-bold tracking-wide text-white">
                        {manualMode ? 'Manual Mode' : 'Auto-Protection'}
                    </h2>
                </div>
                <span className="text-xs text-slate-400 font-mono">{lastUpdate}</span>
            </div>
            
            <p className="text-slate-400 text-sm mb-6">
                {manualMode 
                    ? "System is currently flagging content for review only." 
                    : "System is actively filtering high-confidence threats."}
            </p>

            <div className="flex items-center justify-between">
                <label className="flex items-center cursor-pointer">
                    <div className="relative">
                        <input type="checkbox" className="sr-only" checked={manualMode} onChange={() => setManualMode(!manualMode)} />
                        <div className={`block w-14 h-8 rounded-full transition-colors duration-300 ${manualMode ? 'bg-orange-900' : 'bg-slate-700'}`}></div>
                        <div className={`dot absolute left-1 top-1 bg-white w-6 h-6 rounded-full transition-transform duration-300 ${manualMode ? 'translate-x-6 bg-orange-400' : ''}`}></div>
                    </div>
                    <span className="ml-3 text-sm font-medium text-slate-300">
                        {manualMode ? 'Realtime OFF' : 'Realtime ON'}
                    </span>
                </label>
                
                <button 
                    onClick={handleRefresh}
                    className="flex items-center space-x-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-full text-xs font-bold border border-slate-600 transition-all active:scale-95"
                >
                    <RefreshCw size={14} className={refreshing ? 'animate-spin' : ''} />
                    <span>Refresh Data</span>
                </button>
            </div>
        </div>
      </div>

      {/* Monitored Groups */}
      <div>
        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3 pl-1">Monitored Channels</h3>
        <div className="flex overflow-x-auto space-x-3 pb-2 scrollbar-hide">
            {groups.map(g => (
                <div key={g.id} className={`flex-shrink-0 w-64 p-4 rounded-2xl border transition-all duration-300 ${g.active ? 'bg-gradient-to-br from-slate-800 to-slate-900 border-primary-500/30' : 'bg-slate-900 border-slate-800 opacity-60'}`}>
                    <div className="flex justify-between items-start mb-2">
                        <h4 className="font-bold text-white truncate pr-2">{g.name}</h4>
                        <div className={`w-2 h-2 rounded-full ${g.active ? 'bg-neon-green' : 'bg-slate-500'}`}></div>
                    </div>
                    <p className="text-xs text-slate-500 font-mono mb-3">ID: {g.cid}</p>
                    <div className="flex items-center justify-between">
                        <span className={`text-xs ${g.active ? 'text-neon-green' : 'text-slate-500'}`}>
                            {g.active ? 'Active' : 'Paused'}
                        </span>
                        {/* Toggle Switch Mini */}
                         <div className={`w-8 h-4 rounded-full relative ${g.active ? 'bg-primary-600' : 'bg-slate-700'}`}>
                             <div className={`absolute top-0.5 left-0.5 w-3 h-3 bg-white rounded-full transition-transform ${g.active ? 'translate-x-4' : ''}`}></div>
                         </div>
                    </div>
                </div>
            ))}
        </div>
      </div>

      {/* Summary Stats Grid */}
      <div>
        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3 pl-1">Moderation Impact</h3>
        <div className="grid grid-cols-2 gap-3">
            <StatCard 
                title="Total Actions" 
                value="1,284" 
                subtitle="Last 24 hours" 
                icon={Shield} 
                color="text-blue-400" 
                bg="from-blue-500/10 to-transparent"
            />
            <StatCard 
                title="Deleted" 
                value="842" 
                subtitle="High confidence" 
                icon={UserX} 
                color="text-red-400" 
                bg="from-red-500/10 to-transparent"
            />
            <StatCard 
                title="Auto-Muted" 
                value="156" 
                subtitle="Temporary" 
                icon={VolumeX} 
                color="text-purple-400" 
                bg="from-purple-500/10 to-transparent"
            />
             <StatCard 
                title="Warnings" 
                value="286" 
                subtitle="First offense" 
                icon={AlertTriangle} 
                color="text-orange-400" 
                bg="from-orange-500/10 to-transparent"
            />
        </div>
      </div>
      
      {/* Live Feed Teaser */}
      <div className="glass-panel rounded-2xl p-4 border-l-4 border-neon-blue">
          <div className="flex justify-between items-center mb-2">
              <h4 className="font-bold text-white">Live Activity</h4>
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-neon-blue opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-neon-blue"></span>
              </span>
          </div>
          <div className="space-y-3">
              <div className="text-sm text-slate-300 border-b border-slate-800 pb-2">
                  <span className="text-red-400 font-mono font-bold text-xs">[BLOCKED]</span> User <span className="text-white">@BadActor99</span> posted high toxicity content.
              </div>
              <div className="text-sm text-slate-300">
                  <span className="text-orange-400 font-mono font-bold text-xs">[FLAGGED]</span> User <span className="text-white">@AnonUser</span> flagged for manual review (Score: 65%).
              </div>
          </div>
      </div>

    </div>
  );
};

const StatCard: React.FC<{title: string, value: string, subtitle: string, icon: any, color: string, bg: string}> = ({
    title, value, subtitle, icon: Icon, color, bg
}) => (
    <div className={`p-4 rounded-2xl bg-gradient-to-br ${bg} border border-slate-800 relative overflow-hidden`}>
        <div className={`absolute top-3 right-3 opacity-20 ${color}`}>
            <Icon size={24} />
        </div>
        <div className="relative z-10">
            <h4 className="text-slate-400 text-xs font-medium mb-1">{title}</h4>
            <div className="text-2xl font-bold text-white font-mono mb-1">{value}</div>
            <div className="text-[10px] text-slate-500">{subtitle}</div>
        </div>
    </div>
);